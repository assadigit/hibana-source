# Hibana Kanban — UI Redesign Handoff

This package is an implementation handoff for the Hibana Kanban board redesign across:

- `https://github.com/assadigit/hibana-source/` — canonical web/source repository and the existing project specification pack.
- `https://github.com/assadigit/hibana-desktop` — Go + Wails v2 Windows desktop application that embeds a generated snapshot of the web Kanban UI.

## Start here

1. Read [`AGENT-KICKOFF-PROMPT.md`](AGENT-KICKOFF-PROMPT.md) and give it to your coding agent as the initial task prompt.
2. The agent must first inspect both checked-out repositories and read the authoritative `hibana-source/docs/project-kanban/` specification pack. This handoff supplements that pack; it does **not** replace or supersede it.
3. Use [`docs/UI-REDESIGN-SPEC.md`](docs/UI-REDESIGN-SPEC.md) as the visual and interaction acceptance specification.
4. Use [`docs/DESIGN-SYSTEM.md`](docs/DESIGN-SYSTEM.md) for design tokens, component styling, and icon usage.
5. Use [`docs/REPOSITORY-INTEGRATION.md`](docs/REPOSITORY-INTEGRATION.md) and [`docs/QA-CHECKLIST.md`](docs/QA-CHECKLIST.md) for implementation boundaries and verification.

## Package contents

```text
hibana-kanban-ui-redesign-handoff/
├── README.md
├── AGENT-KICKOFF-PROMPT.md
├── docs/
│   ├── UI-REDESIGN-SPEC.md
│   ├── DESIGN-SYSTEM.md
│   ├── WORKFLOW-STAGES.md
│   ├── REPOSITORY-INTEGRATION.md
│   └── QA-CHECKLIST.md
└── assets/
    ├── empty-state-icons/
    │   ├── new-ideas-lamp.png / .webp
    │   ├── problems-warning.png / .webp
    │   ├── plans-checklist.png / .webp
    │   ├── in-progress-play.png / .webp
    │   └── implemented-check.png / .webp
    ├── source-icon-sheet.png
    ├── icon-contact-sheet-preview.png
    └── references/
        ├── hibana-ui-visual-reference.png
        └── current-ui-before.png
```

## Important decisions already made

- Keep the existing five workflow columns and their exact visible names: **New Ideas → Problems → Plans → In Progress → Implemented**.
- Treat these as workflow stages (Option 1), not as task-type labels. Do not rename or reorder them in this design pass.
- Remove the entire Project Progress card/bar from the top toolbar area.
- Use the supplied five monochrome, low-opacity empty-state illustrations.
- Keep the bottom “Start by adding a task to move your work forward.” hint monochrome and low contrast.
- Preserve all existing product behavior: tasks, transitions, sprints, labels, sync, refresh, theme, settings, sign-out, auth, offline behavior, and API contracts.
- Keep the desktop repository's generated `frontend/dist` island read-only. Shared Kanban UI changes belong in `hibana-source`, followed by the documented island synchronization workflow.

## Assets

The five individual icons are 320 × 320 px RGBA images with transparent backgrounds. PNG is the primary source format; WebP copies are supplied for optional optimized delivery. The source sprite/sheet and a contact-sheet preview are also included.

The assets are deliberately monochrome and already softly rendered. Apply modest CSS opacity (start around `0.60`, then validate on both light and dark themes); do not recolor them with the workflow accent colors.

## Credentials

No credentials, tokens, cookies, private keys, or `.env` files are included. The operator will provide any required credentials directly to the coding agent in its own session. The agent must never echo, commit, persist in tracked files, or include secrets in screenshots/logs/artifacts.

## Reference-image caveat

`assets/references/hibana-ui-visual-reference.png` is a visual direction, not a pixel-perfect implementation contract. Adapt it to the real app shell. In particular, do not introduce a duplicate application-title row if the existing native Windows title bar already provides the app identity. The written specifications and the existing canonical repository docs take precedence over accidental details in a generated image.
