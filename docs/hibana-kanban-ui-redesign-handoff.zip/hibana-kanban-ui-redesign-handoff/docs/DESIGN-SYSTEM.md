# Hibana Kanban — Design System Notes

This document records the visual tokens and component rules for the board redesign. Prefer mapping these values onto existing CSS custom properties/tokens rather than creating a parallel design system.

## 1. Color tokens

### Neutral foundation

| Token | Suggested value | Usage |
|---|---|---|
| `--board-canvas` | `#F7F8FA` | Application board backdrop |
| `--surface` | `#FFFFFF` | Lane and task surfaces in light mode |
| `--border-subtle` | `#E5E9F0` | Default lane/control border |
| `--text-primary` | `#202936` | Titles and important content |
| `--text-secondary` | `#737D8B` | Descriptions and metadata |
| `--text-muted` | `#858E9B` | Low-emphasis helper text |

These values are a starting palette. Prefer existing project tokens when equivalent tokens already exist.

### Workflow accents

| Stage | Accent | Header tint | Usage |
|---|---|---|---|
| New Ideas | `#75A9F7` | `#EDF4FF` | Dot, header tint, Add task border/text, focus/drag target |
| Problems | `#EF8588` | `#FFF0F0` | Same |
| Plans | `#EAA04F` | `#FFF5E9` | Same |
| In Progress | `#D3AC40` | `#FFF8E6` | Same |
| Implemented | `#61BE8B` | `#ECF8F0` | Same |

Use the light tints for lane headers only. Do not apply a solid accent fill to the full lane body. On dark theme, derive appropriate dark tints from the same accents rather than reusing the light hex values unchanged.

### Monochrome illustration palette

The illustrations are supplied as raster files. They should read as quiet gray artwork, not colorful status art. Start at `opacity: 0.60`; tune per theme after visual QA. Do not apply per-column accent filters.

## 2. Typography

Use the app's existing font stack and rendering choices. Avoid introducing a new font dependency for this pass.

| Element | Suggested size | Weight |
|---|---:|---|
| Workspace label | 14–15 px | 600 |
| Column title | 13–14 px | 600 |
| Column count | 11–12 px | 500–600 |
| Empty-state heading | 16–18 px | 600–700 |
| Empty-state description | 13–14 px | 400 |
| Add task label | 13–14 px | 500–600 |
| Bottom helper | 12–13 px | 400 |
| Toolbar labels | 13–14 px | 500–600 |

Maintain a clear contrast hierarchy rather than increasing every font size.

## 3. Shape, spacing, and elevation

- Lane radius: 12–16 px.
- Lane border: 1 px, subtle neutral/tinted border.
- Lane header: 56–64 px high.
- Lane gaps: 10–14 px.
- Toolbar control height: preserve the established 41 px control family where it exists.
- Add task: 42–44 px high, outlined, moderate radius.
- Avoid heavy shadow. Use a restrained hover elevation only where useful.
- Keep spacing consistent with the existing app's scale; do not add arbitrary one-off values if an equivalent token exists.

## 4. Component rules

### Board toolbar

- Workspace selector remains left-aligned.
- Existing board actions remain grouped on the right.
- Sync remains a visible, labeled primary action; preserve existing behavior.
- Refresh and utility actions may use quieter/compact styling but must remain discoverable and accessible.
- Remove the Project Progress component completely.

### Column header

- Accent dot + title + count + overflow menu.
- One overflow button; preserve legacy column actions inside its menu.
- Header tint is light, not saturated.

### Empty-state group

- Illustration above heading, then description, then Add task.
- Icon display target: around 112 px square; preserve aspect ratio.
- CSS opacity starting point: 0.60.
- Keep the group compact and consistent across lanes.

### Bottom helper

- No colored pill or attention-grabbing box.
- Neutral info icon and secondary monochrome text.
- Opacity around 0.62–0.68, adjusted for accessible contrast.

## 5. Icon asset map

| Workflow stage | PNG path | WebP path |
|---|---|---|
| New Ideas | `assets/empty-state-icons/new-ideas-lamp.png` | `.webp` sibling |
| Problems | `assets/empty-state-icons/problems-warning.png` | `.webp` sibling |
| Plans | `assets/empty-state-icons/plans-checklist.png` | `.webp` sibling |
| In Progress | `assets/empty-state-icons/in-progress-play.png` | `.webp` sibling |
| Implemented | `assets/empty-state-icons/implemented-check.png` | `.webp` sibling |

All individual icons are 320 × 320 px RGBA with transparent background. Use individual images, not a CSS crop from the contact sheet.

## 6. Theme adaptation

Light theme: near-white canvas, white lane body, tinted lane header.  
Dark theme: use the app's existing dark surface tokens; derive low-luminance lane header tints; keep accent dots visible; tune illustration opacity independently so the art remains quiet but visible.  
System theme: keep first-paint theme resolution unchanged; do not introduce a flash while the board loads.

## 7. Reference interpretation

The included screenshot illustrates the intended hierarchy. It is not permission to add duplicate title bars, remove Sync, fake a synced state, introduce search/filter without functionality, or alter existing product behavior. The real application and canonical repository docs are authoritative.
