# QA and Acceptance Checklist

Use this checklist before calling the work complete. Record commands, outcomes, and any environment limitations in the agent's final report.

## A. Baseline and repository safety

- [ ] Both repositories inspected; current branches and commit hashes recorded.
- [ ] Existing `git status` captured; no pre-existing user work overwritten.
- [ ] Canonical `hibana-source/docs/project-kanban/` documents read.
- [ ] `GO-DESKTOP-IMPLEMENTATION-GUIDE.md` and ADR-001 read.
- [ ] Current implementation ownership (web source vs desktop-owned layer) confirmed.
- [ ] No generated `frontend/dist` files hand-edited.
- [ ] No secrets, tokens, cookies, personal data, or production payloads committed or written to artifacts.

## B. Layout and visual QA

- [ ] Project Progress card is fully removed (heading, percentage, progress bar, completed/total card summary).
- [ ] Native title bar/window controls remain correct; no duplicate app-title row introduced.
- [ ] Workspace selector remains visible and functional.
- [ ] Existing toolbar actions remain visible/accessible and functional: Sprints, Labels, Sync, Refresh, theme, Settings, Sign out.
- [ ] Sync remains a clearly labeled manual action; no static-only replacement.
- [ ] Five columns remain in the exact order and with exact names.
- [ ] Five lane surfaces use consistent width, height, gap, border, and radius.
- [ ] All lanes fill the available board area; layout does not collapse at minimum window dimensions.
- [ ] Horizontal scrolling works when the viewport cannot fit five usable lanes.
- [ ] No nested scroll trap or clipped menu/tooltip.
- [ ] Column headers have accent dot, title, count, and one overflow menu.
- [ ] Any previous column actions are still available in that menu.
- [ ] Column tint is subtle; lane body stays neutral.
- [ ] No excessive shadow, excessive saturation, or pill-shaped control overload.

## C. Empty-state asset QA

- [ ] New Ideas uses `new-ideas-lamp.png`.
- [ ] Problems uses `problems-warning.png`.
- [ ] Plans uses `plans-checklist.png`.
- [ ] In Progress uses `in-progress-play.png`.
- [ ] Implemented uses `implemented-check.png`.
- [ ] Assets preserve transparent backgrounds and square aspect ratio.
- [ ] Icons are monochrome gray and low opacity; no lane-color tint/filter.
- [ ] Icons remain visible in both light and dark themes.
- [ ] The title and description are readable and localized.
- [ ] Add task remains functional and opens the existing flow for the correct lane.
- [ ] When a task is added/moved into a lane, that lane's empty state disappears.
- [ ] The bottom helper is monochrome, low emphasis, and not enclosed in a loud colored pill.
- [ ] Decorative images are hidden from screen readers; adjacent text provides meaning.

## D. Functional regression checks

- [ ] Create task in each lane.
- [ ] Edit task and verify persistence.
- [ ] Move task across all allowed workflow stages; verify status mapping is unchanged.
- [ ] Drag-and-drop hover/target states are clear and do not obstruct interaction.
- [ ] Delete/archive/complete behavior unchanged where available.
- [ ] Sprints and Labels still work.
- [ ] Refresh still performs its existing behavior.
- [ ] Manual Sync still opens/runs the established flow and presents honest outcomes.
- [ ] Sign out/account switch/login behavior unchanged.
- [ ] No task, user, or server data is silently modified by visual-only tests.

## E. Localization, RTL, theme, accessibility

- [ ] English text uses localization keys.
- [ ] Persian translations are present and accurate.
- [ ] RTL column/toolbars/layout remain usable; icon and text order is correct.
- [ ] Light theme looks correct.
- [ ] Dark theme looks correct; icons neither disappear nor become too prominent.
- [ ] System theme first paint has no flash/regression.
- [ ] Keyboard navigation covers every control and menu.
- [ ] Focus indicator is visible.
- [ ] Tooltips/accessible names exist for icon-only controls.
- [ ] Text and icon contrast remain adequate despite low opacity.
- [ ] Reduced-motion preference is respected.

## F. Desktop packaging/sync checks

- [ ] Shared UI changes made in canonical `hibana-source` source.
- [ ] Official island sync script run using the correct source ref.
- [ ] `frontend/dist` regenerated rather than manually edited.
- [ ] Web-ref pin/version metadata updated through documented steps only.
- [ ] `scripts/sync-island.mjs --check` (or current equivalent) passes.
- [ ] Go vet/tests pass or known baseline failures are documented.
- [ ] Relevant Playwright board/UI probes pass.
- [ ] Desktop build compiles for the supported Windows target.
- [ ] Final diff contains only intended files; no generated noise or unrelated refactors.

## G. Required screenshots in agent report

Capture local/test screenshots for:

1. Empty board, light theme, 1600 × 900 or closest supported size.
2. Empty board at minimum supported desktop dimensions (currently documented as 1100 × 720; verify locally).
3. Populated board with several tasks across columns.
4. Dark theme empty board.
5. Persian RTL empty board.
6. At least one column overflow menu open.
7. Add-task flow or its first step.

Do not include real user credentials, personal data, or production task content in screenshots.
