# Hibana Kanban — UI Redesign Specification

**Status:** Ready for implementation  
**Scope:** Board presentation, empty states, visual hierarchy, and related front-end styling  
**Targets:** `hibana-source` (canonical shared web UI) and `hibana-desktop` (generated desktop island / desktop-owned seams)  
**Design direction:** Clean, restrained, spacious, modern SaaS Kanban; preserve existing Hibana identity and behavior.

---

## 1. Product intent

The goal is to make the existing five-column Hibana board feel like a deliberate, polished workspace rather than a thin row of small panels at the top of a mostly empty white window.

The redesign should:

1. Make the five workflow lanes the visual center of gravity.
2. Establish a clear hierarchy between workspace controls, board-level actions, column headers, and tasks.
3. Make empty columns feel intentional and helpful without filling the board with large illustrations or onboarding cards.
4. Keep the existing pastel workflow identity, while rendering the empty-state illustrations and the bottom helper hint in quiet monochrome.
5. Improve visual consistency without changing task data, status semantics, API behavior, sync logic, or existing product capabilities.

This is a **visual/UI implementation**, not a workflow redesign or backend migration.

## 2. Non-negotiable workflow decision

Keep these five columns, in this order, as workflow stages:

1. **New Ideas**
2. **Problems**
3. **Plans**
4. **In Progress**
5. **Implemented**

Do not replace them with Backlog / Ready / Done or other generic statuses. Do not convert them into task-type labels. Do not rename or reorder persistent status values. The agent must inspect the existing code and canonical project docs to identify the actual stored values and transition rules, and preserve them exactly.

See [`WORKFLOW-STAGES.md`](WORKFLOW-STAGES.md) for the intended user-facing meaning of each stage. Treat those descriptions as explanatory copy, not authorization to alter backend transition rules.

## 3. Application layout

### 3.1 Desktop shell

- Preserve the existing native Windows/Wails title bar and window controls.
- Do not add a second app-title/header row if it would duplicate the current native title bar.
- Maintain the existing desktop minimum window size and shell behavior. The public desktop README currently documents a 1600 × 900 initial window and 1100 × 720 minimum; verify the checked-out source before changing anything.
- Keep the layout stable at the documented minimum size. Use horizontal board scrolling rather than crushing five lanes below a usable width.

### 3.2 Main toolbar

Remove the whole **Project Progress** card from the top toolbar area, including:

- the “Project Progress” heading;
- the percentage figure;
- the progress track/bar;
- the “completed / total” summary that belongs to that card.

Do not replace it with another large summary panel. Reclaim that space for the board.

Retain the workspace selector on the left and the existing product actions on the right. Visually group them so the board itself remains dominant. Preserve the existing functions and labels, including Sprints, Labels, Sync, Refresh, theme, Settings, and Sign out. The exact layout may adapt to existing responsive/overflow behavior.

**Sync safety:** The desktop repo's established behavior requires a clearly labeled, visible Sync action. Do not replace the working manual Sync CTA with a static “Synced” badge. A status presentation may be included only if the manual action remains obvious and functional. Preserve the existing sync modal, state transitions, outcome codes, and EN/FA labels.

**Search and filter:** The generated visual reference contains search/filter icons as a possible future toolbar direction. Do not add decorative or nonfunctional controls. Add them only if the checked-out product already has supported search/filter capabilities or the owner explicitly scopes their implementation. They are not required for this visual pass.

### 3.3 Kanban board geometry

- The board should occupy the available content height beneath the toolbar.
- Use five equal-width lanes at desktop widths, with consistent gutters.
- Give every lane a full-height visual surface so the board reads as five usable work areas, not five short cards.
- At widths where five usable columns cannot fit, horizontally scroll the board. Do not silently hide columns or compress task content to unreadable widths.
- Keep vertical scrolling behavior consistent with the existing app; do not create nested scroll traps.
- Use a subtle neutral app canvas behind white lane surfaces.

Suggested geometry (adjust to the actual app's existing spacing scale):

| Element | Target |
|---|---:|
| Toolbar control height | 40–42 px (preserve existing 41 px controls where already standardized) |
| Lane header height | 56–64 px |
| Lane gap | 10–14 px |
| Lane corner radius | 12–16 px |
| Lane border | 1 px |
| Add-task button height | 42–44 px |
| Empty-state illustration | 104–128 px visual box, preserve 320 px source canvas |

These are design targets, not a mandate to introduce a new spacing framework.

## 4. Column header and lane design

Each lane has:

- a small workflow-color dot;
- the existing column title;
- a compact count badge;
- one overflow/ellipsis menu button.

Header treatment:

- Use a very light tint derived from that lane's accent color.
- Keep the title as the most prominent header element.
- Keep the count badge neutral and visually secondary.
- Use one ellipsis menu rather than two always-visible icon-only actions.
- Preserve the behavior of existing column actions. If the current document/list or download controls represent useful functionality, move those actions into the overflow menu rather than deleting them.
- Provide a tooltip and accessible name for icon-only controls.

Lane body treatment:

- White or near-white task surface.
- Thin, subtle border tinted slightly toward the lane accent.
- No heavy shadow. The lane should feel anchored, not like a floating dashboard card.
- Keep accent color concentrated in the header tint, dot, focus/drag state, and Add task control—not across the entire body.

## 5. Empty-state composition

Show the empty state only when the corresponding lane contains no tasks. As soon as a lane has content, its empty-state group must disappear naturally.

Each empty state uses this hierarchy:

1. Supplied monochrome illustration.
2. Short, bold heading.
3. One or two lines of subdued explanatory copy.
4. Lane-colored outlined **+ Add task** button.

Keep the composition compact and quiet. The illustration must not dominate the lane or force the user to scroll. Place the group in the upper-middle/central working area of the lane, consistent across all five lanes.

### 5.1 Exact English copy

| Stage | Heading | Supporting copy | Asset |
|---|---|---|---|
| New Ideas | No ideas yet | Capture new ideas and potential improvements. | `new-ideas-lamp.png` |
| Problems | No problems yet | Track issues and blockers here. | `problems-warning.png` |
| Plans | No plans yet | Plan upcoming work and define next steps. | `plans-checklist.png` |
| In Progress | Nothing in progress | Move tasks here when you start working. | `in-progress-play.png` |
| Implemented | No completed tasks | Completed tasks will appear here. | `implemented-check.png` |

Use the app's existing localization system. Do not introduce hard-coded English-only strings. Add or update Persian translations in the correct source and preserve right-to-left behavior.

### 5.2 Add-task button

- Keep the action easy to find and clearly interactive.
- Use a subtle outlined treatment using the lane's accent color for border, plus icon, and label.
- Suggested height: 42–44 px; suggested width: 150–175 px (or retain the app's existing consistent button sizing if better).
- Use a consistent radius with the existing app's control language; do not make every control a pill by default.
- Hover/focus states should increase clarity without a large animation or strong fill.
- Preserve the existing create-task flow and the target lane/status mapping.

## 6. Monochrome icon assets

Five generated illustrations are included in `assets/empty-state-icons/`:

- `new-ideas-lamp.png` — lightbulb / ideas;
- `problems-warning.png` — warning triangle / problems;
- `plans-checklist.png` — clipboard checklist / plans;
- `in-progress-play.png` — play symbol / active work;
- `implemented-check.png` — completion check / implemented.

Asset properties:

- 320 × 320 px;
- RGBA;
- transparent background;
- subdued gray monochrome artwork with soft cloud forms;
- PNG primary, WebP alternative.

Usage:

- Use the individual PNGs as the safe primary assets. The WebP files are optional optimized equivalents.
- Preserve the image aspect ratio and transparent padding; do not crop further unless the browser layout requires it.
- Start with CSS opacity around `0.60` (tune within roughly `0.52–0.70` against actual light/dark surfaces).
- Do not tint each icon with the column color. The lane accents belong to the lane UI, not the illustrations.
- Do not add a colored badge, colored background tile, thick drop shadow, or animation to the illustrations.
- Keep them decorative to assistive technology (`alt=""` / presentation semantics) because the adjacent heading and copy provide the meaning.
- Do not distort the art or force a non-square aspect ratio.

The supplied contact sheet is a preview, not a CSS sprite. Use the individual files.

## 7. Bottom board helper hint

Keep the helper message below the board:

> Start by adding a task to move your work forward.

Restyle it to be:

- monochrome gray (no workflow accent color);
- low opacity / secondary in hierarchy;
- small and quiet;
- paired with a subtle monochrome information icon if the existing implementation supports it;
- not enclosed in a prominent colored pill or card.

Suggested starting point: text color `#7B8491` with overall opacity around `0.62–0.68`, then verify legibility. Do not make it so faint that it becomes inaccessible.

Use localized copy for Persian and preserve correct RTL icon/text ordering.

## 8. Visual design direction

Use [`assets/references/hibana-ui-visual-reference.png`](../assets/references/hibana-ui-visual-reference.png) as the primary visual reference. It shows the intended five-lane composition, no top progress card, quiet monochrome illustrations, and subdued bottom hint.

Use `assets/references/current-ui-before.png` only as a before-state reference. The generated design reference is directional; the running app's native title bar, current feature controls, established component patterns, localization, and source repository rules take precedence.

## 9. Populated-board behavior

This package primarily specifies the empty state and overall board shell. The redesign must not degrade populated boards:

- Task cards remain visually dominant over lane decoration.
- Do not tint all task cards with the lane color.
- Keep task titles, priority, labels, due date, checklist/comments metadata, and existing card interactions intact.
- Keep drag-and-drop affordances and status transitions intact.
- On drag, highlight the valid target lane subtly using its accent; do not turn the entire board into saturated color blocks.
- Do not alter task card structure unless the actual implementation requires a small alignment adjustment. Any card redesign beyond necessary consistency work is out of scope unless approved by existing source specs.

## 10. Theme and localization

- Support the existing Light, Dark, and System theme behavior; do not regress zero-JS/first-paint theme selection or cause a flash of the wrong theme.
- Keep lane identity recognizable in dark mode, but use theme-aware tinted backgrounds and borders.
- Monochrome icons should remain visible but subdued on dark surfaces. If needed, tune opacity or use theme-specific opacity—not accent-color filters.
- Keep EN and FA fully functional.
- Verify Persian labels and helper text with `dir="rtl"` and the app's established RTL layout. Do not assume CSS `row-reverse` alone is sufficient.
- Use existing localization keys where possible; avoid duplicating translation infrastructure.

## 11. Interaction and accessibility

- All buttons remain keyboard reachable with visible focus indication.
- Ellipsis menus have accessible names, tooltips, logical focus order, and Escape-to-close behavior consistent with existing menus.
- Empty-state images are decorative; headings and action labels convey all relevant information.
- Maintain readable text contrast. Low opacity is a design preference, not permission to fail contrast requirements.
- Honor reduced-motion preferences.
- Ensure hover is not the only way to reveal a task or column action.
- No inert buttons, fake progress indicators, or nonfunctional mock elements.

## 12. Scope boundaries

### In scope

- Remove top Project Progress summary/progress bar.
- Reclaim toolbar vertical/horizontal space.
- Improve five full-height lane surfaces and lane header hierarchy.
- Replace dual always-visible column controls with one overflow menu while preserving their actions.
- Use the supplied five monochrome empty-state illustrations.
- Add/adjust empty-state copy and compact lane-colored Add task affordances.
- Restyle the bottom helper hint as monochrome and low emphasis.
- Add or adjust CSS/layout and localization strings needed for these changes.
- Keep desktop embedded UI synchronized with the canonical web source using documented tooling.

### Out of scope unless existing authoritative specs require it

- Renaming/reordering/restructuring statuses or task lifecycle rules.
- Database or API schema changes.
- Sync/auth/offline engine modifications.
- Replacing existing toolbar actions or changing their semantics.
- New analytics, WIP limits, new search/filter functionality, or new sprint logic.
- Rebuilding the Wails shell or changing native window/tray behavior.
- A broad redesign of task cards or other screens.

## 13. Acceptance criteria

The implementation is accepted when:

1. The Project Progress card, bar, percentage, and its top summary are gone.
2. The workspace selector and all existing toolbar actions still work.
3. The five existing columns remain exactly named and ordered.
4. All five lane surfaces extend through the usable board height and have consistent sizing/gaps.
5. Each empty lane shows the correct supplied icon, heading, supporting text, and functional Add task action.
6. Empty-state illustrations are monochrome and low opacity; no column accent tint is applied to the art.
7. The bottom helper is monochrome, low emphasis, and legible.
8. Column menus preserve existing column actions.
9. Empty states disappear when a lane receives tasks.
10. Populated tasks, drag/drop, sprints, labels, sync, refresh, theme, settings, sign-out, auth, and offline flows remain unchanged.
11. EN/FA localization and RTL work.
12. Light/Dark/System themes work without first-paint regressions.
13. The desktop island is regenerated through its official sync process and passes drift checks; `frontend/dist` is not hand-edited.
14. Existing tests and the relevant board/UI probes pass; any unavailable test is documented with a reason.
15. No secrets or production data are included in commits, logs, screenshots, or handoff artifacts.
