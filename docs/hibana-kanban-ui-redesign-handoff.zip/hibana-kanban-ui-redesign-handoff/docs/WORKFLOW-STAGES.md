# Workflow Stage Definitions

The owner selected **Option 1: keep the five columns as workflow stages**. This document clarifies their presentation and expected user understanding without changing stored status values or business rules.

| Order | Existing stage name | User-facing meaning | Typical exit signal |
|---:|---|---|---|
| 1 | **New Ideas** | Newly captured ideas, requests, and opportunities waiting for initial triage. | The item is reviewed and its underlying problem/opportunity is understood well enough to investigate or shape. |
| 2 | **Problems** | Discovery and validation: clarify the problem, blocker, need, or risk before committing to a solution. | The problem is sufficiently understood and a solution approach can be planned. |
| 3 | **Plans** | The intended solution is being defined, scoped, and prepared; work is not yet actively underway. | Scope/next steps are clear and the item is ready to be picked up. |
| 4 | **In Progress** | Active execution or development is underway. | The work has been completed and meets the project's existing completion criteria. |
| 5 | **Implemented** | The solution has been implemented/delivered and is considered complete under the existing product rules. | Terminal stage in the normal flow; reopening/backward movement follows existing product behavior. |

## Important implementation constraints

- The order above documents the expected visual sequence. Do not invent or enforce new transition restrictions.
- Preserve the actual status keys, IDs, database values, API payloads, and transition behavior found in the checked-out repositories.
- Some work may legitimately move backward, skip a stage, or be reopened if current behavior allows it.
- Do not reinterpret “Problems” as a label/category. It is a stage in this chosen workflow.
- Do not rename these columns to more generic agile terms.
- If the canonical `hibana-source/docs/project-kanban/` specification defines different operational semantics, follow that authoritative spec and report the discrepancy rather than silently changing product behavior. The stage names and order remain the owner's explicit choice for this redesign.
